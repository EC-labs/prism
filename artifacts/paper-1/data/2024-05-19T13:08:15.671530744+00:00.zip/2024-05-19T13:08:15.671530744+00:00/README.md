# Redis

A base set of requests, executed for 5 minutes and 20 seconds, was run with the
following command:
```bash
./memtier_benchmark --ratio=1:1 --test-time=320 --rate-limiting=130 -t 4 -c 200
```

This command writes to a file with a path such as `/tmp/memtier_rt_<random>.csv`.

We created 2 scenarios throughout this run. The first involved running a new
set of requests, which would saturate the number server's resources. This was done with the following command:
```bash
./src/redis-benchmark -t set -c 1000 -r 100000 -d 10000 -n 1000000 2>/tmp/redis-bench-1.csv
```

To run the second scenario, we first changed the set of core where the
redis-server could run. We then ran a CPU stealing process on the same core
reducing the available runtime for our process. This was done by running the
following command in our collect repository:
```bash
./cpu_contender_script.sh
```
