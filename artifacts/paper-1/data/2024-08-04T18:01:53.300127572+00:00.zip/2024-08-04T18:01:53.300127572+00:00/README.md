# Kafka

## Setup

We use the `docker-compose.yml` file in the `application-metrics` directory to
setup a single Kafka node.

```bash
# Change into the directory that contains the `docker-compose.yml` file
docker compose up
```

We resort to the cc2023 experiment producers to generate the load toward the
Kafka node. The `experiments-config` parameter should point to the path where
the experiment configuration file finds itself. We use the file provided in
`application-metrics/config.json` to generate the load.

```bash
cargo r -r -p experiment-producer -- --brokers <server:port> --topic test --config-file <experiments-config>
```

While the experiments are executing, we start a scraper
`paper-1/benchmarks/kafka/scrape-cc2023-producer` that collects the metrics
produced by the experiment producer's prometheus client. When the experiment
producer terminates, this scraper will automatically print out a csv with the
metrics collected each second.

## Experiment

Our goal is to gradually increase the load on the Kafka node up to the point it
cannot keep up with the requested throughput. This is possible because Kafka
becomes disk bound due to aformentioned configuration variables.

Procedure: 

1. Start the experiment-producer binary pointing it toward the experiment
   configuration file.

The experiment has the following artifacts:

* `config.json`: The experiment producer's configuration file indicating the
  target load
* `docker-compose.yml`: Kafka's docker compose file.
* `metrics.csv`: The result of running the scraper while the
  experiment-producer is executing.
* `producer-rate.csv`: Additional throughput metrics derived from the scraper
  metrics provided by `metrics.csv`.

