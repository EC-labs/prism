# ML Inference

We serve an open source sentiment analysis model to infer the sentiment of a
tweet.

For the machine learning inference server, we wrap the model in a FastAPI
application. Upon receiving a get request coupled with the tweet, the API
responds with the models sentiment prediction.

As for the load, each request consists of a randomly selected tweet from this
[dataset](https://www.kaggle.com/datasets/jp797498e/twitter-entity-sentiment-analysis).
We then generate a double wave load, the load pattern provided in one of
locust's example load patterns.

## Setup

Start by creating

```bash
docker network create ml-inference
```

To build the ML inference server: 

```bash
# Change directory into `./application-metrics/ml-inference`
docker build -t ml-inference .
```

To start the server:
```bash
docker run --network ml-inference --name inference-server --rm --cpus 4 -p 8000:8000 ml-inference
```

### Load

To build the ML load generator: 
```bash
docker build -t ml-load .
```

To start the load generator:
```bash
docker run \
    --rm \
    -v "<path_to_twitter_training>.csv":/usr/src/app/twitter_training.csv \
    -v ./data:/usr/src/data \
    --network ml-inference \
    --name inference-load \
    -p 8089:8089 \
    ml-load
```

To generate the load against the inference server, open locust's UI at
`localhost:8089`, and where it says `Host`, put the inference server's
container name and port, i.e., `http://inference-server:8000`. Press start and
it should start generating load.

## Experiment

1. Start the locust load pattern as described above

The experiment has the following artifacts: 

* `./application-metrics/raw_requests.csv`: Contains the start and end times of
  a request, and its latency 
* `./application-metrics/requests_95.csv`: Per-second 95th percentile latency,
  derived from the previous file
* `./application-metrics/raw_users.csv`: The number of users started at a
  particular instant
* `./application-metrics/load`: Source code for the load generator
* `./application-metrics/ml-inference`: Source code for the ML inference server

